import { configureStore } from "@reduxjs/toolkit";
import CommonSlice from "./Slice";

export const store = configureStore({
  reducer: {
    CommonSlice: CommonSlice,
  },
});
